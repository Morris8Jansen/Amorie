dit is de amorie webshop

Dit is een website die ik maak voor mijn vriendin haar sieraden bedrijf.

nu heeft ze ook een website: lotsofjewelz.com maar ze wilt het graag rebranden en ik wil daar graag aan bijdragen door het maken van een mooie responsive website voor haar te maken.

ik wil graag een database met producten aan deze webite linken, ook moet het klantenbestand in deze database opnemen (het word een mySQL database)
